﻿Console.WriteLine("Integrantes:");
Console.WriteLine("Octavio Henrique Knupp Lucio;");
Console.WriteLine("Nicolas Joly Mussi;");
Console.WriteLine("Eduardo da Cunha.");

string nomeProduto = "";
string categoriaProduto = "";
string valorProduto = "";

double productInitialValue = 0;
double descount = 0;
double productFinalValue = 0;

Console.WriteLine("\n Bem Vindo ao aplicador de descontos: ");
Console.WriteLine("--------------------------------------");

Console.WriteLine("\n Escreva o nome do produto: ");
nomeProduto = Console.ReadLine();
if (nomeProduto == "")
{
    Console.WriteLine(" Nome inválido, preencha o campo! ");
    return;
}


Console.WriteLine("\n Categorias Permitidas: Eletrônicos / Papelaria / Móveis");
Console.WriteLine(" Escreva a categoria do produto: ");
categoriaProduto = Console.ReadLine();
if (categoriaProduto == "")
{
    Console.WriteLine(" Categoria inválida, preencha o campo! ");
    return;
}
else if (categoriaProduto != "Eletrônicos" && categoriaProduto != "Papelaria" && categoriaProduto != "Móveis")
{
    Console.WriteLine(" Categoria inválida, digite corretamente uma das categorias disponíveis! ");
    return;
}

Console.WriteLine("\n Digite o valor do produto: ");
valorProduto = Console.ReadLine();
//valor1 = int.Parse(txt1);
bool valorValido = double.TryParse(valorProduto, out productInitialValue);
if (valorValido == false)
{
    Console.WriteLine(" Valor inválido, utilize um numero! ");
    return;
}
else if (productInitialValue < 0)
{
    Console.WriteLine(" Valor inválido, o valor não pode ser negativo! ");
    return;
}

switch (categoriaProduto)
{
    case "Eletrônicos":
        descount = 15.0 / 100.0;
        break;
    case "Papelaria":
        descount = 10.0 / 100.0;
        break;
    case "Móveis":
        descount = 5.0 / 100.0;
        break;
    default:
        return;
}


productFinalValue = productInitialValue - (productInitialValue * descount);

Console.WriteLine($"\n O produto {nomeProduto}, da categoria {categoriaProduto}, que custava R$ {productInitialValue}, com o desconto de {descount * 100}%, agora custa R$ {productFinalValue}.");


