﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
Console.WriteLine("Pressione qualquer tecla para continuar");
Console.ReadKey();