﻿// See https://aka.ms/new-console-template for more information

using System.Drawing;

Console.WriteLine("Cadastro do aluno");

string nomeAluno = "Eduardo";
int periodo = 2;
float nota1Bim = 7.6f;
float nota2Bim = 8.2f;
float somaNotas = nota1Bim+nota2Bim;
float media = (nota1Bim + nota2Bim) / 2;

Console.WriteLine("seu nome é: " + nomeAluno);
Console.WriteLine("seu periodo é: " + periodo);
Console.WriteLine("sua nota do primeiro bimestre é: " + nota1Bim);
Console.WriteLine("sua nota do segundo bimestre é: " + nota2Bim);
Console.WriteLine("a soma de suas notas é: " + Math.Round(somaNotas,2));
Console.WriteLine("sua média é: " + Math.Round(media, 2));
Console.WriteLine("utilize qualquer tecla para continuar...");
Console.ReadKey();

Console.WriteLine("--------------------------------------------------------");

string txt1 = "";
int valor1 = 0;
string txt2 = "";
int valor2= 0;
double soma = 0;
double subtracao = 0;
double multiplicacao = 0;
double divisao = 0;
double restoDivisao = 0;

Console.Write("Digite um número: ");
txt1 = Console.ReadLine();
//valor1 = int.Parse(txt1);
bool valor1Valido = int.TryParse(txt1, out valor1);
if (valor1Valido == false) {
    Console.WriteLine(" Valor inválido, utilize um numero! ");
    return;
}
else if (valor1 < 1 || valor1 > 10)
{
    Console.WriteLine(" Valor inválido, utilize um numero de 1 a 10! ");
    return;
}

Console.Write("Digite outro número: ");
txt2 = Console.ReadLine();
//valor2 = int.Parse(txt2);
bool valor2Valido = int.TryParse(txt2, out valor2);
if (valor2Valido == false)
{
    Console.WriteLine(" Valor inválido, utilize um valor compatível! ");
    return;
}
else if (valor2 < 1 || valor2 > 10)
{
    Console.WriteLine(" Valor inválido, utilize um numero de 1 a 10! ");
    return;
}
if (valor1<valor2) {
    Console.WriteLine(" Dados Inválidos, o valor 1 deve ser maior que o valor 2! ");
    return;
}

soma = valor1 + valor2;
subtracao = valor1 - valor2;
multiplicacao = valor1 * valor2;
divisao = valor1 / valor2;
restoDivisao = valor1 % valor2;

Console.WriteLine("O valor 1 é: " + valor1);
Console.WriteLine($"O valor 2 é: {valor2}");
Console.WriteLine(string.Concat("A soma de ambos é: " , soma));
Console.WriteLine(string.Concat("A subtracao de ambos é: ", subtracao));
Console.WriteLine(string.Format("A multiplicacao de ambos é: {0}", multiplicacao));
Console.WriteLine("A divisão de ambos é: " + divisao);
Console.WriteLine($"O resto da divisão de ambos é: {restoDivisao}");
Console.WriteLine("utilize qualquer tecla para continuar...");

//Console.WriteLine($"A soma entre {a} e {b} é {c}.");
//bool NOME = TIPO.TryParse(VALOR, out VARIAVEL);

Console.ReadKey();