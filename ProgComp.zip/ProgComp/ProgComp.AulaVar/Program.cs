﻿// See https://aka.ms/new-console-template for more information

/*
Console.WriteLine("Cadastro do aluno")

Console.WriteLine("Digite seu nome: ");
string nomeAluno = Try.Parse(Console.ReadLine());

Console.WriteLine("Digite o período do curso em que você está: ");
int periodo = !String.TryParse(Console.ReadLine());

Console.WriteLine("Digite a nota do seu primeiro bimestre: ");
float nota1Bim = !String.TryParse(Console.ReadLine());

Console.WriteLine("Digite a nota do seu segundo bimestre: ");
float nota2Bim = !String.TryParse(Console.ReadLine());

float somaNotas = nota1Bim+nota2Bim;
float media = (nota1Bim + nota2Bim) / 2;

Console.WriteLine("seu nome é: " + nomeAluno);
Console.WriteLine("seu periodo é: " + periodo);
Console.WriteLine("sua nota do primeiro bimestre é: " + nota1Bim);
Console.WriteLine("sua nota do segundo bimestre é: " + nota2Bim);
Console.WriteLine("a soma de suas notas é: " + somaNotas);
Console.WriteLine("sua média é: " + media);

Console.ReadKey();
 */
using System.Drawing;

Console.WriteLine("Cadastro do aluno");

string nomeAluno = "Eduardo";
int periodo = 2;
float nota1Bim = 7.6f;
float nota2Bim = 8.2f;
float somaNotas = nota1Bim+nota2Bim;
float media = (nota1Bim + nota2Bim) / 2;

Console.WriteLine("seu nome é: " + nomeAluno);
Console.WriteLine("seu periodo é: " + periodo);
Console.WriteLine("sua nota do primeiro bimestre é: " + nota1Bim);
Console.WriteLine("sua nota do segundo bimestre é: " + nota2Bim);
Console.WriteLine("a soma de suas notas é: " + Math.Round(somaNotas,2));
Console.WriteLine("sua média é: " + Math.Round(media, 2));
Console.WriteLine("utilize qualquer tecla para continuar...");
Console.ReadKey();

Console.WriteLine("--------------------------------------------------------");

string txt1 = "";
int valor1 = 0;
string txt2 = "";
int valor2= 0;

Console.Write("Digite um número: ");
txt1 = Console.ReadLine();
valor1 = int.Parse(txt1);

Console.Write("Digite outro número: ");
txt2 = Console.ReadLine();
valor2 = int.Parse(txt2);

float soma = 0;  
float multiplicacao = 0;
float divisao = 0;
float restoDivisao = 0;

soma = valor1 + valor2;
multiplicacao = valor1 * valor2;
divisao = valor1 / valor2;
restoDivisao = valor1 % valor2;

Console.WriteLine("O valor 2 é: " + valor1);
Console.WriteLine($"O valor 2 é: {valor2}");
Console.WriteLine(string.Concat("A soma de ambos é: " , soma));
Console.WriteLine(string.Format("A multiplicacao de ambos é: {0}", multiplicacao));
Console.WriteLine("A divisão de ambos é: " + divisao);
Console.WriteLine($"O resto da divisão de ambos é: {restoDivisao}");
Console.WriteLine("utilize qualquer tecla para continuar...");

//Console.WriteLine($"A soma entre {a} e {b} é {c}.");

Console.ReadKey();